alert("CALCULATOR");

let result = document.getElementById("result");


// result function
let number = document.querySelectorAll(".number");
for(value of number){
    value.addEventListener("click", function(x){
        number = x.target.innerHTML;
        result.value += number;
    })
};
// calculate function
var equal = document.getElementById("equal");
equal.addEventListener("click", function(){
    try{
        result.value = eval(result.value);
    }
    catch(err){
        alert("invalid " + err);
    }
});
//  clear function
let clear = document.getElementById("clear");
clear.addEventListener("click", function(){
 result.value = "";
});







