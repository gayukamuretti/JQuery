$(document).ready(function(){
    var field = ['fname','lname','email'];
    $.each(field, function(index,item){
        $("."+item).on('keyup', function(){
            check(item);
        })
    });
    function check(item){
        var input = $("."+item).val();
        var output = $("."+item).attr("name");
        if(input == ''){
           $("."+item).closest(".form-group").find("small").text("*Please fill your "+ output + ".").css("color","red");
           $("."+item).addClass('is-invalid').removeClass('is-valid');
        }
        else{
            $("."+item).closest(".form-group").find("small").text(" ").css("color","green");
            $("."+item).removeClass('is-invalid');
            $("."+item).addClass('is-valid');
            return 'true';
        }
    }

    
    $(".validate").on('keyup', function () {
        var nameValidate = $(this).val();
        var regexValidate = /^[a-zA-Z ]*$/;
        var value = nameValidate.replace(/[^a-zA-Z ]/g, '');
        if (!regexValidate.test(nameValidate)) {
            $(this).val(value);
        }
    });
    

    $("#email").keyup(mail);

    function mail() {
        var checkmail = $("#email").val();
        var check = /^([a-z0-9_.])+\@([a-z])+\.([a-z])+$/;
        if (checkmail == "") {
            $("#emailcheck").html("*Please fill your email.").css("color","red");
            $(".email").addClass('is-invalid').removeClass('is-valid');
        }
        else if (checkmail.match(check)) {
           $("#emailcheck").html(" ").css("color","green");
           $(".email").addClass('is-valid').removeClass('is-invalid');
           return 'true';
        }
        else {
            $("#emailcheck").html(" @ and . is missing.").css("color","red");
            $(".email").addClass('is-invalid').removeClass('is-valid');
        }
    } 

    //radio button function()
    $("#female").on('click',gender);
    $("#male").on('click',gender);
    function gender() {
        var getSelectedValue = $('input[name="gender"]:checked').val();
        if (getSelectedValue != null) {
            $("#gendercheck").html('Selected').css("color","green");
            $("#gender").addClass('is-valid').removeClass('is-invalid');
            return 'true';
        } else {
          
            $("#gendercheck").html('*Please select gender.').css("color","red");
            $("#gender").addClass('is-invalid').removeClass('is-valid');
        }
    
    }

    
    // checkbox function()
    $(".checkbox").click(function(){

        checkbox();

    });

    function checkbox(){
        if($("input:checkbox").filter(":checked").length < 1) {
            $('#subcheck').html('*Please select atleast one.').css("color", "red");
            $('.checkbox').addClass('is-invalid').removeClass('is-valid');
        }
        else{
            $('#subcheck').html('Valid').css("color", "green");
            $('.checkbox').addClass('is-valid').removeClass('is-invalid');
            return 'true';
        }

    };
   
    
    // select function()
    $(".place").change(function () {
        validateCity();
    });
    function validateCity() {
        if ($("#location").val() == "") {
            $("#location").addClass("is-invalid");
            $("#selectcheck").show().html("*Please select your place.").css("color", "red");
        }
        else if ($("#location").val() != "") {
           $("#selectcheck").hide();
           $("#location").removeClass("is-invalid").addClass("is-valid");
           return 'true';

        } 
    }
    
    

    toastr.options = {
        "closeButton": true,
        "debug": false,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": true,
        "onclick": null,
        "showDuration": 800,
        "hideDuration": 1000,
        "timeOut": 5000,
        "extendedTimeOut": 1000,
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    }
    
    // submit function()
    $("#submit").on('click', submit);
    function submit(e){
        e.preventDefault();
        $.each(field, function (index, item) {
            check(item);
        })
        gender();
        checkbox();
        mail();
        validateCity();
        var result =  check()  && gender()  && checkbox()   && mail() &&  validateCity();
        if (result == "true") {
            toastr.success("Form filled successfully.");
        }
        else{
            toastr.error("Please fill all the  fields.");
        }
         

        var arr = [];
        var object = {};
  
    $("#submit").click(function(event) 
    {
        event.preventDefault();
        object["firstname"] = $("#firstname").val();
        object["lastname"] =  $("#lastname").val();
        object["mail"]  = $("#email").val();
        object["select"]  = $('input[name="gender"]:checked').val();
        
        var checkbox = new Array();
        $('input[type="checkbox"]:checked').each(function(){
            checkbox.push($(this).val());
        })
        object["comments"]  = $("#comment").val();
        object["select"]  = $('#location').val();
        arr.push(object);
        var appenditems; 
        for (var i = 0; i < arr.length; i++) {
        appenditems = `<tr> 
                <td>${arr[i].firstname}</td>
                <td>${arr[i].lastname}</td>
                <td>${arr[i].mail}</td>
                <td>${arr[i].select}</td>
                <td>${checkbox}</td>
                <td>${arr[i].comments}</td>
                <td>${arr[i].select}</td>
              </tr>`;
    }
    $("tbody").append(appenditems);
    });
  
    };


    $("#reset").on("click", function(e){
        var field = ['fname','lname','email', 'comment' , 'place'];
        e.preventDefault();
        $.each(field, function(index, item){
            $("input:checked").removeAttr("checked");
            $("." + item).val("");
            $("small").text("");
            $('input[type ="radio"]').removeClass("is-invalid").removeClass("is-valid");
            $('input[type ="checkbox"]').removeClass("is-invalid").removeClass("is-valid");
            $("." + item).removeClass("is-invalid").removeClass("is-valid");
        })
    })  
});